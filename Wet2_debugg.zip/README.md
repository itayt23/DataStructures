# DataStructures
this is Technion wet2 excresize, the main datastructors implement here are: RankTree, UnionFind, ChainHash,
